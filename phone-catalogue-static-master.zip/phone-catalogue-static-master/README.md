# phone-catalogue-static
Static pages of phone catalogue
